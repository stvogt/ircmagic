ircmagic
========

Open Source IRC processing library
